package com.example.swhackathon.File;


import com.example.swhackathon.domain.parkingInfo;
import com.example.swhackathon.Repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
@Service
public class CSVReader {

    private final bukguParkingRepository bukgu;
    private final dalseoguParkingRepository dalseo;
    private final dalseonggunParkingRepository dalseong;
    private final dongguParkingRepository dounggu;
    private final jungguParkingRepository junggu;
    private final namguParkingRepository namgu;
    private final seoguParkingRepository seogu;
    private final suseongguParkingRepository suseonggu;

    @PostConstruct
    public void readCSV() {
        File csv = new File("C:\\Users\\SAMSUNG\\Desktop\\새 폴더 (2)\\swhackathon\\swhackathon\\src\\main\\resources\\parkingSpace.csv");
//        File csv = new File("../../../..resources/parkingSpace.csv");
        BufferedReader br = null;
        String line = "";

        try {
            br = new BufferedReader(new FileReader(csv));
            parkingInfo info;

            //첫줄 미리 읽음
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] lineArr = line.split(",");

                //
                log.info("line[0] = {}", lineArr[0]);
                //

                info = new parkingInfo();
                info.setGu(lineArr[0]);
                info.setStartLocation(lineArr[1]);
                info.setWeeklyStartTime(lineArr[3]);
                info.setWeeklyEndTime(lineArr[4]);

                Map apiId = getApiId(info.getStartLocation());
                info.setId((String) apiId.get("id"));
                info.setUrl((String) apiId.get("place_url"));

                if (info.getGu().equals("북구")){
                    bukgu.saveBuk(info);
                    log.info("북구");
                }
                else if (info.getGu().equals("달서구")) {
                    dalseo.saveDalseo(info);
                    log.info("달서구");
                }
                else if (info.getGu().equals("달성군")) {
                    dalseong.saveDalseong(info);
                    log.info("달성군");
                }
                else if (info.getGu().equals("동구")) {
                    dounggu.saveDongu(info);
                    log.info("동구");
                }
                else if (info.getGu().equals("중구")){
                    junggu.saveJungu(info);
                    log.info("중구");
                }
                else if (info.getGu().equals("남구")) {
                    namgu.saveNamgu(info);
                    log.info("남구");
                } else if (info.getGu().equals("서구")) {
                    seogu.saveSeogu(info);
                    log.info("서구");
                    watch(seogu);
                } else if (info.getGu().equals("수성구")) {
                    suseonggu.saveSuseong(info);
                    log.info("수성구");
                    watch(suseonggu);
                }
            }



        } catch (FileNotFoundException e) {
            log.info("FileNotFound");
        } catch (IOException e) {
            log.info("FileNotFound");
        } finally {
            try {
                if (br != null) {
                    br.close(); // 사용 후 BufferedReader를 닫아준다.
                }
            } catch (IOException e) {
                log.info("FileNotFound");
            }
        }
    }

    private void watch(Repo repo) {
        //test
        List<parkingInfo> all = repo.findAll();
        for (parkingInfo o : all) {

            log.info("id = {} || content = {}",o.getId(), o.getStartLocation());
        }
    }

    public Map getApiId(String keyword) {

        log.info("keyword = {}", keyword);
        final RestTemplate restTemplate = new RestTemplate();
        String URL = "https://dapi.kakao.com/v2/local/search/keyword.json?";

        HttpHeaders headers = new HttpHeaders(); // 헤더에 key들을 담아준다.
        headers.set("Authorization", "KakaoAK 268528632d8a8f569e56b2f5a67353fe");
        URL = URL + "query=" + keyword + "&size=1";

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> json = restTemplate.exchange(URL, HttpMethod.GET, entity, Map.class);
        ArrayList<Map> documents = (ArrayList<Map>) json.getBody().get("documents");
        return documents.get(0);
    }

}