package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class jungguParkingRepository {

    static final Map<String, parkingInfo> jungguRepo = new HashMap<>();

    public parkingInfo saveJungu(parkingInfo info) {
        jungguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(jungguRepo.values());
    }

}
