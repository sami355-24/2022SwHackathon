package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class suseongguParkingRepository implements Repo {

    static final Map<String, parkingInfo> suseongguRepo = new HashMap<>();

    public parkingInfo saveSuseong(parkingInfo info) {

        suseongguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(suseongguRepo.values());
    }

}
