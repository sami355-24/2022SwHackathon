package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;

import java.util.List;

public interface Repo {
    List<parkingInfo> findAll();
}
