package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class dalseonggunParkingRepository {

    static final Map<String, parkingInfo> dalseonggun = new HashMap<>();

    public parkingInfo saveDalseong(parkingInfo info) {
        dalseonggun.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(dalseonggun.values());
    }

}
