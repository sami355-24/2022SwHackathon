package com.example.swhackathon.domain;

import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@RequiredArgsConstructor
@Data
@Getter
@Setter
public class parkingInfo {

    /**
     * id, url-> 카카오 API에서 가져옴
     * */
    String id;
    String url;

    String gu;
    String startLocation;
    String weeklyStartTime;
    String weeklyEndTime;

}
