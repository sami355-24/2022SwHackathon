package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class bukguParkingRepository implements Repo {

    static final Map<String, parkingInfo> bokguRepo = new HashMap<>();

    public parkingInfo saveBuk(parkingInfo info){
        bokguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll(){
        return new ArrayList<>(bokguRepo.values());
    }

}
