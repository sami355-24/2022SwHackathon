package com.example.swhackathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwhackathonApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwhackathonApplication.class, args);
	}

}
