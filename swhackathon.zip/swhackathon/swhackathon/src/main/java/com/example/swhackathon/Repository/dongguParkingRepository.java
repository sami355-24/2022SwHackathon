package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class dongguParkingRepository {

    static final Map<String, parkingInfo> dongguRepo = new HashMap<>();

    public parkingInfo saveDongu(parkingInfo info) {
        dongguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(dongguRepo.values());
    }

}
