package com.example.swhackathon.controller;

import com.example.swhackathon.Repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;

@Slf4j
@Controller
@RequiredArgsConstructor
public class mapController {

    private final bukguParkingRepository bukgu;
    private final dalseoguParkingRepository dalseo;
    private final dalseonggunParkingRepository dalseong;
    private final dongguParkingRepository dounggu;
    private final jungguParkingRepository junggu;
    private final jungguParkingRepository namgu;
    private final seoguParkingRepository seogu;
    private final suseongguParkingRepository suseonggu;

    @GetMapping("/")
    public String daegu(Model model) throws IOException {
        log.info("daegu");
        return "Daegu";
    }

    @GetMapping("/bukgu")
    public String bukgu(Model model) throws IOException {
        log.info("bukgu");
        model.addAttribute("list", bukgu.findAll());
        model.addAttribute("templates/img", "C:\\Users\\SAMSUNG\\Desktop\\새 폴더 (2)\\swhackathon\\swhackathon\\src\\main\\resources\\img");
        return "Bukgu";
    }

    @GetMapping("/dalseogu")
    public String dalseogu(Model model) throws IOException {
        log.info("dalseogu");
        model.addAttribute("list", dalseo.findAll());
        return "Dalseogu";
    }

    @GetMapping("/dalseongun")
    public String dalseongun(Model model) throws IOException {
        log.info("dalseongun");
        model.addAttribute("list", dalseong.findAll());
        return "Dalseongun";
    }

    @GetMapping("/dongu")
    public String doungu(Model model) throws IOException {
        log.info("dongu");
        model.addAttribute("list", dounggu.findAll());
        return "Dongu";
    }

    @GetMapping("/jungu")
    public String jungu(Model model) throws IOException {
        log.info("jungu");
        model.addAttribute("list", junggu.findAll());
        return "Jungu";
    }

    @GetMapping("/namgu")
    public String namgu(Model model) throws IOException {
        log.info("namgu");
        model.addAttribute("list", namgu.findAll());
        return "Namgu";
    }

    @GetMapping("/seogu")
    public String seogu(Model model) throws IOException {
        log.info("seogu");
        model.addAttribute("list", seogu.findAll());
        return "Seogu";
    }

    @GetMapping("/suseongu")
    public String suseongu(Model model) throws IOException {
        log.info("suseongu");
        model.addAttribute("list", suseonggu.findAll());
        return "Suseongu";
    }

}
