package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class seoguParkingRepository implements Repo {

    static final Map<String, parkingInfo> seoguRepo = new HashMap<>();

    public parkingInfo saveSeogu(parkingInfo info) {
        seoguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(seoguRepo.values());
    }

}
