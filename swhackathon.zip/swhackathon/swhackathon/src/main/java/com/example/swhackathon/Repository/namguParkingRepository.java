package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class namguParkingRepository {

    static final Map<String, parkingInfo> namguRepo = new HashMap<>();

    public parkingInfo saveNamgu(parkingInfo info) {
        namguRepo.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(namguRepo.values());
    }

}
