package com.example.swhackathon.Repository;

import com.example.swhackathon.domain.parkingInfo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class dalseoguParkingRepository {

    static final Map<String, parkingInfo> dalseogu = new HashMap<>();

    public parkingInfo saveDalseo(parkingInfo info) {
        dalseogu.put(info.getId(), info);
        return info;
    }

    public List<parkingInfo> findAll() {
        return new ArrayList<>(dalseogu.values());
    }

}
